package site.paranoia.mapper;

import site.paranoia.domain.User;
import site.paranoia.utils.MyMapper;

public interface UserMapper extends MyMapper<User> {

}
