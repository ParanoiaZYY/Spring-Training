package site.paranoia.controller;

public class UserController {

}
